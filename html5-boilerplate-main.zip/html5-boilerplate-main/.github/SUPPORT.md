# Support

For personal support requests with HTML5 Boilerplate please use Stack Overflow
([`html5boilerplate`](https://stackoverflow.com/questions/tagged/html5boilerplate)
tag).
